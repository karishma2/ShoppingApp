import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl ,FormArray,Validators} from '@angular/forms';
import { Router } from '@angular/router';
import{ActivatedRoute} from '@angular/router';
import{Recipe} from '../recipe.model'
import{RecipeService} from '../recipe.service'

@Component({
  selector: 'app-recipe-edit',
  templateUrl: './recipe-edit.component.html',
  styleUrls: ['./recipe-edit.component.css']
})
export class RecipeEditComponent implements OnInit {
 id:number;
 editMode=false;
 recipeForm:FormGroup;
  constructor(private route:ActivatedRoute,private recipeService:RecipeService, private router: Router) { }

  ngOnInit() {
  this.route.params
  .subscribe((params)=>{
  this.id=params['id'];
  this.editMode= params['id']!=null;
  console.log(this.editMode);
  this.initForm();
  }
  );
  
  }
  
  private initForm(){
  let recipeName='';
  let recipeImagePath='';
  let recipeDescription='';
  let recipeIngredients= new FormArray([]);
  
  if(this.editMode){
   const recipe = this.recipeService.getDetailRecipe(this.id);
   recipeName = recipe.name;
   recipeImagePath=recipe.imagePath;
   recipeDescription=recipe.description;
   if(recipe.ingredients){
   for(let ingredient of recipe.ingredients){
   recipeIngredients.push(
   new FormGroup({
   'name':new FormControl(ingredient.name,Validators.required),
   'amount':new FormControl(ingredient.amount,[Validators.required,
   Validators.pattern(/^[1-9]+[0-9]*$/)])
   })
   )
   
   }
   }
  }
  this.recipeForm= new FormGroup({
  'name':new FormControl(recipeName,Validators.required),
  'imagePath':new FormControl(recipeImagePath,Validators.required),
  'description':new FormControl(recipeDescription,Validators.required),
  'ingredients': recipeIngredients
  });
  
  }
  OnSubmit(){
  console.log(this.recipeForm);
  const newRecipe=new Recipe(this.recipeForm.value.name,
  this.recipeForm.value.description,
  this.recipeForm.value.imagePath,
  this.recipeForm.value.ingredients)
  if(this.editMode){
  this.recipeService.updateRecipe(newRecipe,this.id);
  }
  else
  this.recipeService.addRecipes(newRecipe);
  
  this.onCancel();
  }
  onIngredientAdd(){
  (<FormArray>this.recipeForm.get('ingredients')).push(
  new FormGroup({
  'name': new FormControl(null,Validators.required),
  'amount': new FormControl(null,[Validators.required,
   Validators.pattern(/^[1-9]+[0-9]*$/)])
  }))
  }
  onCancel(){
  this.router.navigate(['../'],{relativeTo:this.route});
  }
  deleteIngredient(i){
 (<FormArray>this.recipeForm.get('ingredients')).removeAt(i);
 
  }
  

}
